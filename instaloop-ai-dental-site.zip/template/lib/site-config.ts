export const siteConfig = {
  businessName: "InstaLoop AI",
  niche: "Dental Clinics",
  phoneDisplay: "+91 77628 29652",
  phoneHref: "tel:+917762829652",
  bookingUrl: "https://cal.com/ravishankar-sharma-mc5jfo/important",
  pricing: {
    monthly: 797,
    includedMinutes: 600,
    overagePerMinute: 0.75,
  },
  retell: {
    publicKey: process.env.NEXT_PUBLIC_RETELL_PUBLIC_KEY ?? "",
    voiceAgentId: process.env.NEXT_PUBLIC_RETELL_VOICE_AGENT_ID ?? "",
  },
  stats: {
    unansweredCallsPct: 62,
    voicemailNoCallbackPct: 85,
    lostToCompetitorPct: 62,
    annualLossUSD: 126000,
  },
};
